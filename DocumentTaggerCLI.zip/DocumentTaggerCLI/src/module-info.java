/**
 * 
 */
/**
 * 
 */
module DocumentTaggerCLI {
}